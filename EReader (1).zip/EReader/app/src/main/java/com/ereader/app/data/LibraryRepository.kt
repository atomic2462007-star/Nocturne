package com.ereader.app.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.provider.OpenableColumns
import com.ereader.app.epub.EpubParser
import com.ereader.app.epub.TextUtil
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.io.IOException

class LibraryRepository(private val ctx: Context, private val db: AppDatabase) {

    /** ينسخ الملف إلى تخزين التطبيق (ليبقى متاحًا دائمًا) ويضيفه للمكتبة. يعيد معرّف الكتاب. */
    suspend fun import(uri: Uri): Long = withContext(Dispatchers.IO) {
        val cr = ctx.contentResolver
        var name = "book"
        var size = -1L
        cr.query(uri, null, null, null, null)?.use { c ->
            if (c.moveToFirst()) {
                val ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                val si = c.getColumnIndex(OpenableColumns.SIZE)
                if (ni >= 0) c.getString(ni)?.let { name = it }
                if (si >= 0 && !c.isNull(si)) size = c.getLong(si)
            }
        }
        val lower = name.lowercase()
        val type = when {
            lower.endsWith(".pdf") -> "pdf"
            lower.endsWith(".epub") -> "epub"
            else -> when (cr.getType(uri)) {
                "application/pdf" -> "pdf"
                "application/epub+zip" -> "epub"
                else -> throw IOException("الصيغة غير مدعومة (PDF أو EPUB فقط)")
            }
        }
        if (size >= 0) db.books().findDuplicate(name, size)?.let { return@withContext it.id }

        val booksDir = File(ctx.filesDir, "books").apply { mkdirs() }
        val coversDir = File(ctx.filesDir, "covers").apply { mkdirs() }
        val stamp = "${System.currentTimeMillis()}_${(1000..9999).random()}"
        val dest = File(booksDir, "$stamp.$type")
        var coverFile: File? = null
        try {
            val input = cr.openInputStream(uri) ?: throw IOException("تعذر فتح الملف")
            input.use { i -> dest.outputStream().use { o -> i.copyTo(o) } }
            val baseName = name.substringBeforeLast('.')
            val now = System.currentTimeMillis()
            var title = baseName
            var author = ""
            val rtl: Boolean
            val cover = File(coversDir, "$stamp.jpg")

            if (type == "pdf") {
                rtl = TextUtil.looksRtl(baseName)
                try {
                    val pfd = ParcelFileDescriptor.open(dest, ParcelFileDescriptor.MODE_READ_ONLY)
                    PdfRenderer(pfd).use { r ->
                        if (r.pageCount == 0) throw IOException("ملف PDF فارغ")
                        r.openPage(0).use { p ->
                            val w = 480
                            val h = (p.height * (w.toFloat() / p.width)).toInt().coerceAtLeast(1)
                            val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                            bmp.eraseColor(Color.WHITE)
                            p.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                            FileOutputStream(cover).use { bmp.compress(Bitmap.CompressFormat.JPEG, 85, it) }
                            coverFile = cover
                        }
                    }
                    pfd.close()
                } catch (e: SecurityException) {
                    throw IOException("الملف محمي بكلمة مرور")
                }
            } else {
                val info = try { EpubParser.inspect(dest) } catch (e: Exception) { throw IOException("ملف EPUB غير صالح") }
                info.title?.takeIf { it.isNotBlank() }?.let { title = it }
                author = info.author.orEmpty()
                rtl = info.rtl
                info.cover?.let { bytes ->
                    val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                    BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o)
                    var s = 1
                    while (o.outWidth / (s * 2) >= 500) s *= 2
                    val o2 = BitmapFactory.Options().apply { inSampleSize = s }
                    BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o2)?.let { bmp ->
                        FileOutputStream(cover).use { bmp.compress(Bitmap.CompressFormat.JPEG, 88, it) }
                        coverFile = cover
                    }
                }
            }
            db.books().insert(
                BookEntity(
                    title = title, author = author, originalName = name, sizeBytes = size,
                    filePath = dest.absolutePath, type = type, coverPath = coverFile?.absolutePath,
                    isRtl = rtl, addedAt = now, lastOpenedAt = now
                )
            )
        } catch (e: Exception) {
            dest.delete()
            coverFile?.delete()
            throw e
        }
    }

    suspend fun delete(book: BookEntity) = withContext(Dispatchers.IO) {
        File(book.filePath).delete()
        book.coverPath?.let { File(it).delete() }
        db.books().delete(book.id)
    }
}
