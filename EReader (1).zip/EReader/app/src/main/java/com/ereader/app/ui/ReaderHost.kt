package com.ereader.app.ui

import android.app.Activity
import android.widget.Toast
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.ereader.app.AppViewModel
import com.ereader.app.data.BookEntity
import com.ereader.app.data.HighlightEntity
import com.ereader.app.epub.Chapter
import com.ereader.app.epub.EpubParser
import com.ereader.app.reader.Page
import com.ereader.app.reader.Paginator
import com.ereader.app.reader.PdfDoc
import com.ereader.app.reader.PdfPageText
import com.ereader.app.reader.PdfTextExtractor
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.max
import kotlin.math.min

private val DarkBg = Color.Black
private val LightBg = Color(0xFFF5F0E6)

@Composable
fun ReaderHost(vm: AppViewModel, id: Long) {
    val activity = LocalContext.current as Activity
    val view = LocalView.current
    val ui = remember { ReaderUiState() }
    val book by remember(id) { vm.observeBook(id) }.collectAsState(initial = null)

    DisposableEffect(Unit) {
        val c = WindowCompat.getInsetsController(activity.window, view)
        c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        view.keepScreenOn = true
        onDispose {
            view.keepScreenOn = false
            c.show(WindowInsetsCompat.Type.systemBars())
            setBrightness(activity, -1f)
        }
    }
    LaunchedEffect(ui.bars) {
        val c = WindowCompat.getInsetsController(activity.window, view)
        if (ui.bars) c.show(WindowInsetsCompat.Type.systemBars()) else c.hide(WindowInsetsCompat.Type.systemBars())
    }
    // رسائل الترجمة أثناء القراءة
    LaunchedEffect(Unit) { vm.message.collect { Toast.makeText(activity, it, Toast.LENGTH_LONG).show() } }

    val b = book
    LaunchedEffect(b?.brightness) { setBrightness(activity, b?.brightness ?: -1f) }
    if (b == null) {
        Box(Modifier.fillMaxSize().background(Color.Black), Alignment.Center) { CircularProgressIndicator(color = Color.Gray) }
        return
    }
    val onBack = { vm.openBookId.value = null }
    if (b.type == "pdf") PdfReader(b, vm, ui, onBack) else EpubReader(b, vm, ui, onBack)
}

@Composable
private fun CenterMessage(text: String, onBack: () -> Unit) {
    Box(Modifier.fillMaxSize().background(Color.Black), Alignment.Center) {
        Text(text, color = Color(0xFFBDBDBD), fontSize = 15.sp, modifier = Modifier.clickable { onBack() }.padding(24.dp))
    }
}

/** -1 = يسار الشاشة، 1 = يمين الشاشة، 0 = المنتصف */
private fun tapSide(x: Float, w: Float): Int = when {
    x < w * 0.28f -> -1
    x > w * 0.72f -> 1
    else -> 0
}

/* ============================== EPUB ============================== */

private data class Sel(val chapter: Int, val start: Int, val end: Int, val aS: Int, val aE: Int, val existing: Long? = null)

@Composable
fun EpubReader(book: BookEntity, vm: AppViewModel, ui: ReaderUiState, onBack: () -> Unit) {
    val density = LocalDensity.current
    var chapters by remember(book.filePath) { mutableStateOf<List<Chapter>?>(null) }
    var error by remember(book.filePath) { mutableStateOf<String?>(null) }
    LaunchedEffect(book.filePath) {
        try {
            val ch = withContext(Dispatchers.IO) { EpubParser.readChapters(File(book.filePath)) }
            if (ch.isEmpty()) error = "لا يوجد نص قابل للعرض في هذا الكتاب" else chapters = ch
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            error = "تعذر قراءة الكتاب"
        }
    }
    val anchor = remember { intArrayOf(book.lastChapter, book.lastOffset) }

    BoxWithConstraints(Modifier.fillMaxSize().background(if (book.isDark) DarkBg else LightBg).displayCutoutPadding()) {
        val marginPx = with(density) { 26.dp.toPx() }
        val topPx = with(density) { 44.dp.toPx() }
        val bottomPx = with(density) { 56.dp.toPx() }
        val wPx = (constraints.maxWidth - 2 * marginPx).toInt()
        val hPx = (constraints.maxHeight - topPx - bottomPx).toInt()
        val textPx = with(density) { book.fontSizeSp.sp.toPx() }

        var pages by remember { mutableStateOf<List<Page>?>(null) }
        LaunchedEffect(chapters, wPx, hPx, book.fontSizeSp, book.fontFamily, book.lineSpacing, book.isDark) {
            val ch = chapters ?: return@LaunchedEffect
            val tc = if (book.isDark) 0xFFD6D6D6.toInt() else 0xFF222222.toInt()
            val hc = if (book.isDark) 0xFFFFFFFF.toInt() else 0xFF000000.toInt()
            pages = withContext(Dispatchers.Default) {
                Paginator.paginate(ch, wPx, hPx, textPx, book.fontFamily, book.lineSpacing, tc, hc)
            }
        }

        val pg = pages
        val ch = chapters
        when {
            error != null -> CenterMessage(error!!, onBack)
            pg == null || ch == null -> Column(
                Modifier.fillMaxSize(), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally
            ) {
                CircularProgressIndicator(color = Color.Gray)
                Spacer(Modifier.height(14.dp))
                Text("جارٍ تجهيز الصفحات…", color = Color(0xFF8A8A8A), fontSize = 13.sp)
            }
            pg.isEmpty() -> CenterMessage("لا يوجد نص قابل للعرض", onBack)
            else -> key(pg) { EpubPager(book, vm, ui, pg, ch, anchor, marginPx, topPx, wPx, onBack) }
        }
    }
}

private fun pageOffsetAt(page: Page, x: Float, y: Float, marginPx: Float, topPx: Float, wPx: Int, strict: Boolean): Int? {
    val ly = y - topPx + page.top
    val lx = x - marginPx
    if (strict && (ly < page.top || ly > page.bottom || lx < 0f || lx > wPx)) return null
    val line = page.layout.getLineForVertical(ly.toInt().coerceIn(page.top, page.bottom - 1)).coerceIn(page.startLine, page.endLine - 1)
    return page.layout.getOffsetForHorizontal(line, lx.coerceIn(0f, wPx.toFloat())).coerceIn(page.startChar, page.endChar)
}

private fun wordBounds(text: CharSequence, i: Int): Pair<Int, Int> {
    val lo = (i - 120).coerceAtLeast(0)
    val hi = (i + 120).coerceAtMost(text.length)
    val sub = text.subSequence(lo, hi).toString()
    if (sub.isEmpty()) return i to i
    val bi = java.text.BreakIterator.getWordInstance()
    bi.setText(sub)
    val rel = (i - lo).coerceIn(0, sub.length - 1)
    val s = (if (bi.isBoundary(rel)) rel else bi.preceding(rel)).coerceAtLeast(0)
    val e = bi.following(s).let { if (it == java.text.BreakIterator.DONE) sub.length else it }
    return (lo + s) to (lo + e)
}

@Composable
private fun EpubPager(
    book: BookEntity, vm: AppViewModel, ui: ReaderUiState, pages: List<Page>, chapters: List<Chapter>,
    anchor: IntArray, marginPx: Float, topPx: Float, wPx: Int, onBack: () -> Unit
) {
    val scope = rememberCoroutineScope()
    val pagerState = rememberPagerState(initialPage = Paginator.findPage(pages, anchor[0], anchor[1])) { pages.size }
    val bookmarks by remember(book.id) { vm.observeBookmarks(book.id) }.collectAsState(initial = emptyList())
    val highlights by remember(book.id) { vm.observeHighlights(book.id) }.collectAsState(initial = emptyList())
    val toc = remember(chapters) { chapters.mapIndexed { i, c -> TocItem(c.title, i) } }
    var sel by remember { mutableStateOf<Sel?>(null) }
    var translateText by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(pagerState) {
        snapshotFlow { pagerState.currentPage }.collect { p ->
            sel = null
            val pg = pages[p.coerceIn(0, pages.size - 1)]
            anchor[0] = pg.chapter
            anchor[1] = pg.startChar
            vm.savePosition(book.id, pg.chapter, pg.startChar, (p + 1f) / pages.size)
        }
    }

    val cur = pages[pagerState.currentPage.coerceIn(0, pages.size - 1)]
    val bookmarked = bookmarks.any { it.chapter == cur.chapter && it.charOffset in cur.startChar until cur.endChar }
    val rtl = book.isRtl
    val hlState by rememberUpdatedState(highlights)

    fun go(delta: Int) {
        scope.launch { pagerState.animateScrollToPage((pagerState.currentPage + delta).coerceIn(0, pages.size - 1)) }
    }

    val onSelStart: (Page, Int) -> Unit = { pg, idx ->
        val txt = pg.layout.text
        if (txt.isNotEmpty()) {
            val (ws, we) = wordBounds(txt, idx.coerceIn(0, txt.length - 1))
            val s = ws.coerceAtLeast(pg.startChar)
            val e = we.coerceAtMost(pg.endChar)
            sel = Sel(pg.chapter, s, e, s, e)
            ui.bars = false
        }
    }
    val onSelDrag: (Page, Int) -> Unit = { pg, idx ->
        val cs = sel
        val txt = pg.layout.text
        if (cs != null && txt.isNotEmpty()) {
            val (ws, we) = wordBounds(txt, idx.coerceIn(0, txt.length - 1))
            val ns = min(cs.aS, ws).coerceAtLeast(pg.startChar)
            val ne = max(cs.aE, we).coerceAtMost(pg.endChar)
            if (ns != cs.start || ne != cs.end) sel = cs.copy(start = ns, end = ne)
        }
    }

    Box(Modifier.fillMaxSize()) {
        CompositionLocalProvider(LocalLayoutDirection provides if (rtl) LayoutDirection.Rtl else LayoutDirection.Ltr) {
            Box(
                Modifier.fillMaxSize().pointerInput(rtl) {
                    detectTapGestures(onLongPress = { }) { off ->
                        if (sel != null) { sel = null; return@detectTapGestures }
                        val pg = pages[pagerState.currentPage.coerceIn(0, pages.size - 1)]
                        val idx = pageOffsetAt(pg, off.x, off.y, marginPx, topPx, wPx, true)
                        if (idx != null) {
                            val hl = hlState.firstOrNull { it.chapter == pg.chapter && idx >= it.startChar && idx < it.endChar }
                            if (hl != null) {
                                sel = Sel(hl.chapter, hl.startChar, hl.endChar, hl.startChar, hl.endChar, hl.id)
                                ui.bars = false
                                return@detectTapGestures
                            }
                        }
                        val side = tapSide(off.x, size.width.toFloat())
                        if (side == 0) ui.bars = !ui.bars
                        else {
                            ui.bars = false
                            go(if ((side == 1) != rtl) 1 else -1)
                        }
                    }
                }
            ) {
                HorizontalPager(state = pagerState, modifier = Modifier.fillMaxSize(), beyondViewportPageCount = 1) { i ->
                    val pg = pages[i]
                    EpubPageView(
                        pg, marginPx, topPx, wPx,
                        highlights.filter { it.chapter == pg.chapter },
                        sel?.takeIf { it.chapter == pg.chapter },
                        onSelStart, onSelDrag
                    )
                }
            }
        }

        val s = sel
        if (s != null) {
            SelectionBar(
                Modifier.align(Alignment.BottomCenter).padding(bottom = 76.dp),
                existing = s.existing != null,
                onColor = { c ->
                    val txt = cur.layout.text.subSequence(s.start, s.end).toString().replace('\n', ' ').trim()
                    if (s.existing != null) vm.setHighlightColor(s.existing, c)
                    else vm.addHighlight(book.id, s.chapter, s.start, s.end, c, txt.take(160))
                    sel = null
                },
                onTranslate = { translateText = cur.layout.text.subSequence(s.start, s.end).toString().replace('\n', ' ') },
                onDelete = { s.existing?.let { vm.deleteHighlight(it) }; sel = null },
                onClose = { sel = null }
            )
        }

        ReaderOverlay(
            book = book, vm = vm, ui = ui, isPdf = false,
            pageIndex = pagerState.currentPage, pageCount = pages.size,
            topLabel = chapters.getOrNull(cur.chapter)?.title,
            toc = toc, bookmarks = bookmarks, highlights = highlights, bookmarked = bookmarked,
            onBack = onBack,
            onToggleBookmark = {
                val hit = bookmarks.filter { it.chapter == cur.chapter && it.charOffset in cur.startChar until cur.endChar }
                if (hit.isNotEmpty()) hit.forEach { vm.deleteBookmark(it.id) }
                else vm.addBookmark(book.id, cur.chapter, cur.startChar, cur.preview().ifBlank { "صفحة ${pagerState.currentPage + 1}" })
            },
            onJumpBookmark = { b -> scope.launch { pagerState.scrollToPage(Paginator.findPage(pages, b.chapter, b.charOffset)) } },
            onJumpHighlight = { h -> scope.launch { pagerState.scrollToPage(Paginator.findPage(pages, h.chapter, h.startChar)) } },
            onJumpToc = { t -> scope.launch { pagerState.scrollToPage(Paginator.findPage(pages, t.chapter, 0)) } },
            onGoToPage = { scope.launch { pagerState.scrollToPage(it.coerceIn(0, pages.size - 1)) } }
        )

        translateText?.let { TranslateDialog(it) { translateText = null } }
    }
}

@Composable
private fun EpubPageView(
    page: Page, marginPx: Float, topPx: Float, wPx: Int,
    highlights: List<HighlightEntity>, sel: Sel?,
    onSelStart: (Page, Int) -> Unit, onSelDrag: (Page, Int) -> Unit
) {
    val paint = remember { android.graphics.Paint().apply { style = android.graphics.Paint.Style.FILL; isAntiAlias = true } }
    val path = remember { android.graphics.Path() }
    val startCb by rememberUpdatedState(onSelStart)
    val dragCb by rememberUpdatedState(onSelDrag)
    Canvas(
        Modifier.fillMaxSize().pointerInput(page) {
            detectDragGesturesAfterLongPress(
                onDragStart = { off ->
                    pageOffsetAt(page, off.x, off.y, marginPx, topPx, wPx, true)?.let { startCb(page, it) }
                },
                onDrag = { change, _ ->
                    change.consume()
                    pageOffsetAt(page, change.position.x, change.position.y, marginPx, topPx, wPx, false)?.let { dragCb(page, it) }
                },
                onDragEnd = { },
                onDragCancel = { }
            )
        }
    ) {
        drawIntoCanvas { c ->
            val n = c.nativeCanvas
            n.save()
            n.translate(marginPx, topPx - page.top)
            n.clipRect(0f, page.top.toFloat(), wPx.toFloat(), page.bottom.toFloat())
            for (h in highlights) {
                val s = max(h.startChar, page.startChar)
                val e = min(h.endChar, page.endChar)
                if (s < e) {
                    paint.color = HlColors.color(h.color)
                    paint.alpha = 120
                    path.reset()
                    page.layout.getSelectionPath(s, e, path)
                    n.drawPath(path, paint)
                }
            }
            if (sel != null) {
                val s = max(sel.start, page.startChar)
                val e = min(sel.end, page.endChar)
                if (s < e) {
                    paint.color = 0xFF3D8BFF.toInt()
                    paint.alpha = 110
                    path.reset()
                    page.layout.getSelectionPath(s, e, path)
                    n.drawPath(path, paint)
                }
            }
            page.layout.draw(n)
            n.restore()
        }
    }
}

/* ============================== PDF ============================== */

// الوضع الداكن لـ PDF: قلب الألوان + تدوير اللون 180° ليحافظ على ألوان الصور قدر الإمكان
private val DarkPdfFilter: ColorFilter = ColorFilter.colorMatrix(ColorMatrix(floatArrayOf(
    0.494f, -1.230f, -0.124f, 0f, 219.3f,
    -0.366f, -0.370f, -0.124f, 0f, 219.3f,
    -0.366f, -1.230f, 0.736f, 0f, 219.3f,
    0f, 0f, 0f, 1f, 0f
)))

private data class PdfSel(val page: Int, val start: Int, val end: Int, val aS: Int, val aE: Int, val existing: Long? = null)

private fun fitRect(boxW: Float, boxH: Float, bw: Int, bh: Int): androidx.compose.ui.geometry.Rect {
    val s = min(boxW / bw, boxH / bh)
    val w = bw * s
    val h = bh * s
    return androidx.compose.ui.geometry.Rect((boxW - w) / 2f, (boxH - h) / 2f, (boxW + w) / 2f, (boxH + h) / 2f)
}

@Composable
fun PdfReader(book: BookEntity, vm: AppViewModel, ui: ReaderUiState, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val doc = remember(book.filePath) { try { PdfDoc(File(book.filePath)) } catch (e: Exception) { null } }
    val extractor = remember(book.filePath) { PdfTextExtractor(ctx, File(book.filePath)) }
    DisposableEffect(doc, extractor) { onDispose { doc?.close(); extractor.close() } }
    if (doc == null || doc.pageCount == 0) {
        CenterMessage("تعذر فتح ملف PDF (قد يكون تالفًا أو محميًا بكلمة مرور)", onBack)
        return
    }

    val scope = rememberCoroutineScope()
    val count = doc.pageCount
    val pagerState = rememberPagerState(initialPage = book.lastChapter.coerceIn(0, count - 1)) { count }
    val bookmarks by remember(book.id) { vm.observeBookmarks(book.id) }.collectAsState(initial = emptyList())
    val highlights by remember(book.id) { vm.observeHighlights(book.id) }.collectAsState(initial = emptyList())
    val rtl = book.isRtl
    val filter: ColorFilter? = if (book.isDark) DarkPdfFilter else null
    var sel by remember { mutableStateOf<PdfSel?>(null) }
    var translateText by remember { mutableStateOf<String?>(null) }
    val hlState by rememberUpdatedState(highlights)

    LaunchedEffect(pagerState) {
        snapshotFlow { pagerState.currentPage }.collect { p ->
            sel = null
            vm.savePosition(book.id, p, 0, (p + 1f) / count)
        }
    }
    val cur = pagerState.currentPage
    val bookmarked = bookmarks.any { it.chapter == cur }

    fun go(delta: Int) {
        scope.launch { pagerState.animateScrollToPage((pagerState.currentPage + delta).coerceIn(0, count - 1)) }
    }

    BoxWithConstraints(Modifier.fillMaxSize().background(if (book.isDark) DarkBg else Color(0xFFEDEDED))) {
        val renderW = (constraints.maxWidth * 1.5f).toInt().coerceIn(600, 2200)
        CompositionLocalProvider(LocalLayoutDirection provides if (rtl) LayoutDirection.Rtl else LayoutDirection.Ltr) {
            HorizontalPager(state = pagerState, modifier = Modifier.fillMaxSize(), beyondViewportPageCount = 1) { i ->
                val bmp by produceState<ImageBitmap?>(null, doc, i, renderW) {
                    value = try {
                        doc.render(i, renderW).asImageBitmap()
                    } catch (e: CancellationException) {
                        throw e
                    } catch (e: Exception) {
                        null
                    }
                }
                val pt by produceState<PdfPageText?>(null, extractor, i) { value = extractor.page(i) }

                fun normPoint(p: Offset, size: IntSize): Pair<Float, Float>? {
                    val b = bmp ?: return null
                    val r = fitRect(size.width.toFloat(), size.height.toFloat(), b.width, b.height)
                    return ((p.x - r.left) / r.width) to ((p.y - r.top) / r.height)
                }

                ZoomablePage(
                    onTap = { raw, content, size ->
                        if (sel != null) {
                            sel = null
                        } else {
                            val t = pt
                            val np = normPoint(content, size)
                            val idx = if (t != null && np != null) t.nearestChar(np.first, np.second, true) else null
                            val hl = if (idx != null) hlState.firstOrNull { it.chapter == i && idx >= it.startChar && idx < it.endChar } else null
                            if (hl != null) {
                                sel = PdfSel(i, hl.startChar, hl.endChar, hl.startChar, hl.endChar, hl.id)
                                ui.bars = false
                            } else {
                                val side = tapSide(raw.x, size.width.toFloat())
                                if (side == 0) ui.bars = !ui.bars
                                else {
                                    ui.bars = false
                                    go(if ((side == 1) != rtl) 1 else -1)
                                }
                            }
                        }
                    },
                    onSelStart = { p, size ->
                        val t = pt
                        val np = normPoint(p, size)
                        val idx = if (t != null && np != null) t.nearestChar(np.first, np.second, true) else null
                        if (t != null && idx != null) {
                            val (ws, we) = t.wordBounds(idx)
                            sel = PdfSel(i, ws, we, ws, we)
                            ui.bars = false
                        }
                    },
                    onSelDrag = { p, size ->
                        val t = pt
                        val cs = sel
                        val np = normPoint(p, size)
                        val idx = if (t != null && np != null) t.nearestChar(np.first, np.second, false) else null
                        if (t != null && cs != null && cs.page == i && idx != null) {
                            val (ws, we) = t.wordBounds(idx)
                            val ns = min(cs.aS, ws)
                            val ne = max(cs.aE, we)
                            if (ns != cs.start || ne != cs.end) sel = cs.copy(start = ns, end = ne)
                        }
                    }
                ) {
                    Box(Modifier.fillMaxSize()) {
                        val b = bmp
                        if (b != null) {
                            Image(b, null, Modifier.fillMaxSize(), contentScale = ContentScale.Fit, colorFilter = filter)
                        } else {
                            Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator(color = Color(0xFF777777), strokeWidth = 2.dp) }
                        }
                        val t = pt
                        if (b != null && t != null) {
                            val pageHls = highlights.filter { it.chapter == i }
                            val s = sel?.takeIf { it.page == i }
                            Canvas(Modifier.fillMaxSize()) {
                                val r = fitRect(size.width, size.height, b.width, b.height)
                                fun paintRange(start: Int, end: Int, color: Color) {
                                    for (rc in t.lineRects(start, end)) {
                                        drawRoundRect(
                                            color,
                                            topLeft = Offset(r.left + rc.left * r.width, r.top + rc.top * r.height),
                                            size = Size(rc.width() * r.width, rc.height() * r.height),
                                            cornerRadius = CornerRadius(3f)
                                        )
                                    }
                                }
                                for (h in pageHls) paintRange(h.startChar, h.endChar, Color(HlColors.color(h.color)).copy(alpha = 0.45f))
                                if (s != null) paintRange(s.start, s.end, Color(0xFF3D8BFF).copy(alpha = 0.40f))
                            }
                        }
                    }
                }
            }
        }

        val s = sel
        if (s != null) {
            SelectionBar(
                Modifier.align(Alignment.BottomCenter).padding(bottom = 76.dp),
                existing = s.existing != null,
                onColor = { c ->
                    if (s.existing != null) vm.setHighlightColor(s.existing, c)
                    else scope.launch {
                        val t = extractor.page(s.page)
                        val snip = t?.text?.substring(s.start.coerceAtLeast(0), s.end.coerceAtMost(t.text.length))?.replace('\n', ' ')?.trim().orEmpty()
                        vm.addHighlight(book.id, s.page, s.start, s.end, c, snip.take(160).ifBlank { "صفحة ${s.page + 1}" })
                    }
                    sel = null
                },
                onTranslate = {
                    scope.launch {
                        val t = extractor.page(s.page)
                        val txt = t?.text?.substring(s.start.coerceAtLeast(0), s.end.coerceAtMost(t.text.length))?.replace('\n', ' ')?.trim().orEmpty()
                        if (txt.isNotBlank()) translateText = txt
                    }
                },
                onDelete = { s.existing?.let { vm.deleteHighlight(it) }; sel = null },
                onClose = { sel = null }
            )
        }
    }

    ReaderOverlay(
        book = book, vm = vm, ui = ui, isPdf = true,
        pageIndex = cur, pageCount = count, topLabel = null,
        toc = emptyList(), bookmarks = bookmarks, highlights = highlights, bookmarked = bookmarked,
        onBack = onBack,
        onToggleBookmark = {
            val hit = bookmarks.filter { it.chapter == cur }
            if (hit.isNotEmpty()) hit.forEach { vm.deleteBookmark(it.id) }
            else vm.addBookmark(book.id, cur, 0, "صفحة ${cur + 1}")
        },
        onJumpBookmark = { b -> scope.launch { pagerState.scrollToPage(b.chapter.coerceIn(0, count - 1)) } },
        onJumpHighlight = { h -> scope.launch { pagerState.scrollToPage(h.chapter.coerceIn(0, count - 1)) } },
        onJumpToc = {},
        onGoToPage = { scope.launch { pagerState.scrollToPage(it.coerceIn(0, count - 1)) } }
    )
    translateText?.let { TranslateDialog(it) { translateText = null } }
}

/**
 * صفحة PDF قابلة للتكبير بإصبعين (أو النقر مرتين). السحب بإصبع واحد لا يُعترض وهي غير مكبّرة.
 * الضغط المطوّل ثم السحب يحدد نصًا (الإحداثيات تُمرَّر بعد إلغاء التكبير).
 */
@Composable
private fun ZoomablePage(
    onTap: (Offset, Offset, IntSize) -> Unit,
    onSelStart: (Offset, IntSize) -> Unit,
    onSelDrag: (Offset, IntSize) -> Unit,
    content: @Composable () -> Unit
) {
    var scale by remember { mutableFloatStateOf(1f) }
    var offset by remember { mutableStateOf(Offset.Zero) }
    val tapCb by rememberUpdatedState(onTap)
    val startCb by rememberUpdatedState(onSelStart)
    val dragCb by rememberUpdatedState(onSelDrag)

    fun toContent(p: Offset, size: IntSize): Offset {
        val c = Offset(size.width / 2f, size.height / 2f)
        return (p - c - offset) / scale + c
    }

    Box(
        Modifier.fillMaxSize().clipToBounds()
            .pointerInput(Unit) {
                detectTapGestures(
                    onDoubleTap = { if (scale > 1f) { scale = 1f; offset = Offset.Zero } else scale = 2.5f },
                    onLongPress = { },
                    onTap = { tapCb(it, toContent(it, size), size) }
                )
            }
            .pointerInput(Unit) {
                awaitEachGesture {
                    awaitFirstDown(requireUnconsumed = false)
                    do {
                        val ev = awaitPointerEvent()
                        val consumed = ev.changes.any { it.isConsumed }
                        if (!consumed && (ev.changes.size > 1 || scale > 1f)) {
                            val zoom = ev.calculateZoom()
                            val pan = ev.calculatePan()
                            val ns = (scale * zoom).coerceIn(1f, 5f)
                            scale = ns
                            val maxX = size.width * (ns - 1f) / 2f
                            val maxY = size.height * (ns - 1f) / 2f
                            offset = if (ns <= 1f) Offset.Zero
                            else Offset((offset.x + pan.x).coerceIn(-maxX, maxX), (offset.y + pan.y).coerceIn(-maxY, maxY))
                            ev.changes.forEach { if (it.positionChanged()) it.consume() }
                        }
                    } while (ev.changes.any { it.pressed })
                }
            }
            .pointerInput(Unit) {
                detectDragGesturesAfterLongPress(
                    onDragStart = { startCb(toContent(it, size), size) },
                    onDrag = { change, _ -> change.consume(); dragCb(toContent(change.position, size), size) },
                    onDragEnd = { },
                    onDragCancel = { }
                )
            }
    ) {
        Box(
            Modifier.fillMaxSize().graphicsLayer(scaleX = scale, scaleY = scale, translationX = offset.x, translationY = offset.y)
        ) { content() }
    }
}
