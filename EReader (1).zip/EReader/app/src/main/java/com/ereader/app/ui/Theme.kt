package com.ereader.app.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val Scheme = darkColorScheme(
    primary = Color(0xFFE6E6E6),
    onPrimary = Color.Black,
    background = Color.Black,
    onBackground = Color(0xFFE6E6E6),
    surface = Color(0xFF111111),
    onSurface = Color(0xFFE6E6E6),
    surfaceVariant = Color(0xFF1C1C1C),
    onSurfaceVariant = Color(0xFFA8A8A8),
    secondaryContainer = Color(0xFF333333),
    onSecondaryContainer = Color.White,
    outline = Color(0xFF555555),
    surfaceContainerLow = Color(0xFF151515),
    surfaceContainer = Color(0xFF151515),
    surfaceContainerHigh = Color(0xFF1A1A1A),
    surfaceContainerHighest = Color(0xFF1F1F1F)
)

@Composable
fun EReaderTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Scheme, content = content)
}
