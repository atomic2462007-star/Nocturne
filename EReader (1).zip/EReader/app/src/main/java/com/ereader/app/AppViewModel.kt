package com.ereader.app

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.room.withTransaction
import com.ereader.app.data.*
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class TranslationState(val title: String, val done: Int, val total: Int)

class AppViewModel(app: Application) : AndroidViewModel(app) {
    private val db = AppDatabase.get(app)
    private val repo = LibraryRepository(app, db)
    private val translator = BookTranslator(app, db)

    val books: StateFlow<List<BookEntity>?> =
        db.books().observeAll().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val openBookId = MutableStateFlow<Long?>(null)
    val importing = MutableStateFlow(false)
    val translation = MutableStateFlow<TranslationState?>(null)
    val message = MutableSharedFlow<String>(extraBufferCapacity = 8)
    private var translationJob: Job? = null

    fun observeBook(id: Long): Flow<BookEntity?> = db.books().observe(id)
    fun observeBookmarks(id: Long): Flow<List<BookmarkEntity>> = db.bookmarks().observe(id)
    fun observeHighlights(id: Long): Flow<List<HighlightEntity>> = db.highlights().observe(id)

    fun importUris(uris: List<Uri>, openFirst: Boolean = false) {
        viewModelScope.launch {
            importing.value = true
            var ok = 0
            var last: Long? = null
            for (u in uris) {
                try {
                    last = repo.import(u)
                    ok++
                } catch (e: Exception) {
                    message.tryEmit(e.message ?: "تعذر إضافة الملف")
                }
            }
            importing.value = false
            if (ok > 0 && !openFirst) message.tryEmit(if (ok == 1) "تمت إضافة الكتاب" else "تمت إضافة $ok كتب")
            if (openFirst && last != null) openBookId.value = last
        }
    }

    fun deleteBook(b: BookEntity) { viewModelScope.launch { repo.delete(b) } }

    fun translateBook(b: BookEntity) {
        if (translationJob?.isActive == true) { message.tryEmit("هناك ترجمة جارية بالفعل"); return }
        translation.value = TranslationState(b.title, 0, 1)
        message.tryEmit("بدأت الترجمة، تابع التقدم من المكتبة وابقِ التطبيق مفتوحًا")
        translationJob = viewModelScope.launch {
            try {
                translator.translate(b) { d, t -> translation.value = TranslationState(b.title, d, t) }
                message.tryEmit("اكتملت الترجمة، ستجد النسخة العربية في المكتبة")
            } catch (e: CancellationException) {
                message.tryEmit("أُوقفت الترجمة، التقدم محفوظ ويكتمل لاحقًا")
                throw e
            } catch (e: Exception) {
                message.tryEmit(e.message ?: "فشلت الترجمة")
            } finally {
                translation.value = null
            }
        }
    }

    fun cancelTranslation() { translationJob?.cancel() }

    fun savePosition(id: Long, chapter: Int, offset: Int, progress: Float) {
        viewModelScope.launch { db.books().savePosition(id, chapter, offset, progress, System.currentTimeMillis()) }
    }
    fun saveText(id: Long, size: Float, family: String, spacing: Float) {
        viewModelScope.launch { db.books().saveText(id, size, family, spacing) }
    }
    fun saveBrightness(id: Long, b: Float) { viewModelScope.launch { db.books().saveBrightness(id, b) } }
    fun saveDark(id: Long, dark: Boolean) { viewModelScope.launch { db.books().saveDark(id, dark) } }
    fun saveRtl(id: Long, rtl: Boolean) { viewModelScope.launch { db.books().saveRtl(id, rtl) } }

    fun addBookmark(bookId: Long, chapter: Int, offset: Int, label: String) {
        viewModelScope.launch {
            db.bookmarks().insert(BookmarkEntity(bookId = bookId, chapter = chapter, charOffset = offset, label = label, createdAt = System.currentTimeMillis()))
        }
    }
    fun deleteBookmark(id: Long) { viewModelScope.launch { db.bookmarks().delete(id) } }

    fun addHighlight(bookId: Long, chapter: Int, start: Int, end: Int, color: Int, snippet: String) {
        viewModelScope.launch {
            db.withTransaction {
                db.highlights().deleteOverlapping(bookId, chapter, start, end)
                db.highlights().insert(
                    HighlightEntity(bookId = bookId, chapter = chapter, startChar = start, endChar = end, color = color,
                        snippet = snippet, createdAt = System.currentTimeMillis())
                )
            }
        }
    }
    fun setHighlightColor(id: Long, color: Int) { viewModelScope.launch { db.highlights().setColor(id, color) } }
    fun deleteHighlight(id: Long) { viewModelScope.launch { db.highlights().delete(id) } }
}
