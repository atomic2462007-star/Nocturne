package com.ereader.app.reader

import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.text.*
import android.text.style.*
import com.ereader.app.epub.Chapter

/** صفحة واحدة = مقطع من أسطر StaticLayout الخاص بالفصل. */
class Page(val chapter: Int, val layout: StaticLayout, val startLine: Int, val endLine: Int) {
    val startChar: Int = layout.getLineStart(startLine)
    val endChar: Int = layout.getLineEnd(endLine - 1)
    val top: Int = layout.getLineTop(startLine)
    val bottom: Int = layout.getLineBottom(endLine - 1)
    fun preview(): String =
        layout.text.subSequence(startChar, minOf(endChar, startChar + 60)).toString().replace('\n', ' ').trim()
}

object Paginator {
    fun typeface(key: String): Typeface = when (key) {
        "sans" -> Typeface.SANS_SERIF
        "sans_medium" -> Typeface.create("sans-serif-medium", Typeface.NORMAL)
        "mono" -> Typeface.MONOSPACE
        else -> Typeface.SERIF
    }

    fun paginate(
        chapters: List<Chapter>, widthPx: Int, heightPx: Int,
        textSizePx: Float, family: String, lineSpacing: Float,
        textColor: Int, headColor: Int
    ): List<Page> {
        val paint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = textColor
            textSize = textSizePx
            typeface = typeface(family)
        }
        val indent = (textSizePx * 1.3f).toInt()
        val pages = ArrayList<Page>()
        val w = widthPx.coerceAtLeast(100)
        val h = heightPx.coerceAtLeast(100)

        chapters.forEachIndexed { ci, ch ->
            val sb = SpannableStringBuilder()
            for (b in ch.blocks) {
                val start = sb.length
                sb.append(b.text).append('\n')
                val end = sb.length
                if (b.level > 0) {
                    val scale = when (b.level) { 1 -> 1.55f; 2 -> 1.35f; 3 -> 1.2f; else -> 1.1f }
                    sb.setSpan(RelativeSizeSpan(scale), start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                    sb.setSpan(StyleSpan(Typeface.BOLD), start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                    sb.setSpan(ForegroundColorSpan(headColor), start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                    if (b.level <= 2) {
                        sb.setSpan(AlignmentSpan.Standard(Layout.Alignment.ALIGN_CENTER), start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                    }
                    sb.append('\n') // مسافة بعد العنوان
                } else {
                    sb.setSpan(LeadingMarginSpan.Standard(indent, 0), start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                }
            }
            while (sb.isNotEmpty() && sb[sb.length - 1] == '\n') sb.delete(sb.length - 1, sb.length)
            if (sb.isEmpty()) return@forEachIndexed

            val layout = StaticLayout.Builder.obtain(sb, 0, sb.length, paint, w)
                .setLineSpacing(0f, lineSpacing)
                .setIncludePad(true)
                .setJustificationMode(Layout.JUSTIFICATION_MODE_INTER_WORD)
                .setBreakStrategy(Layout.BREAK_STRATEGY_HIGH_QUALITY)
                .setHyphenationFrequency(Layout.HYPHENATION_FREQUENCY_NONE)
                .setTextDirection(TextDirectionHeuristics.FIRSTSTRONG_LTR)
                .build()

            var line = 0
            while (line < layout.lineCount) {
                val top = layout.getLineTop(line)
                var end = line
                while (end < layout.lineCount && layout.getLineBottom(end) - top <= h) end++
                if (end == line) end = line + 1
                pages.add(Page(ci, layout, line, end))
                line = end
            }
        }
        return pages
    }

    /** أقرب صفحة لموضع محفوظ (فصل، حرف). */
    fun findPage(pages: List<Page>, chapter: Int, offset: Int): Int {
        val i = pages.indexOfLast { it.chapter < chapter || (it.chapter == chapter && it.startChar <= offset) }
        return i.coerceAtLeast(0)
    }
}
