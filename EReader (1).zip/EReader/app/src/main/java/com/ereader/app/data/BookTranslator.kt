package com.ereader.app.data

import android.content.Context
import com.ereader.app.epub.Block
import com.ereader.app.epub.Chapter
import com.ereader.app.epub.EpubParser
import com.ereader.app.reader.PdfTextExtractor
import com.ereader.app.reader.pdfParagraphs
import com.ereader.app.translate.Translator
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException

/** يترجم كتابًا كاملًا إلى العربية وينشئ نسخة عربية جديدة في المكتبة. التقدم يُحفظ فيستأنف بعد أي انقطاع. */
class BookTranslator(private val ctx: Context, private val db: AppDatabase) {

    suspend fun translate(book: BookEntity, onProgress: (Int, Int) -> Unit): Long = withContext(Dispatchers.IO) {
        if (book.isRtl) throw IOException("هذا الكتاب عربي بالفعل")
        db.books().findDuplicate("tr:${book.id}", 0L)?.let { return@withContext it.id }

        onProgress(0, 1)
        val src = loadSource(book)
        if (src.isEmpty()) throw IOException("لا يوجد نص قابل للترجمة في هذا الكتاب")

        val dir = File(ctx.filesDir, "translations").apply { mkdirs() }
        val file = File(dir, "${book.id}.jsonl")
        val done = if (file.exists()) file.useLines { it.count() } else 0
        onProgress(done, src.size)

        for (i in done until src.size) {
            ensureActive()
            val ch = src[i]
            val tr = Translator.translateList(listOf(ch.title) + ch.blocks.map { it.text })
            val blocks = JSONArray()
            ch.blocks.forEachIndexed { k, b -> blocks.put(JSONArray().put(b.level).put(tr.getOrElse(k + 1) { b.text })) }
            val obj = JSONObject().put("t", tr.firstOrNull() ?: ch.title).put("b", blocks)
            file.appendText(obj.toString() + "\n")
            onProgress(i + 1, src.size)
        }

        var coverCopy: String? = null
        book.coverPath?.let { cp ->
            val f = File(cp)
            if (f.exists()) {
                val dest = File(f.parentFile, "tr_${book.id}.jpg")
                f.copyTo(dest, overwrite = true)
                coverCopy = dest.absolutePath
            }
        }
        val now = System.currentTimeMillis()
        db.books().insert(
            BookEntity(
                title = "ترجمة: ${book.title}", author = book.author, originalName = "tr:${book.id}", sizeBytes = 0L,
                filePath = file.absolutePath, type = "epub", coverPath = coverCopy,
                isRtl = true, addedAt = now, lastOpenedAt = now
            )
        )
    }

    private suspend fun loadSource(book: BookEntity): List<Chapter> {
        if (book.type == "epub") return EpubParser.readChapters(File(book.filePath))
        val ex = PdfTextExtractor(ctx, File(book.filePath))
        try {
            val n = ex.count()
            val out = ArrayList<Chapter>()
            for (i in 0 until n) {
                val t = ex.page(i) ?: continue
                val paras = pdfParagraphs(t.text)
                if (paras.isNotEmpty()) out.add(Chapter("صفحة ${i + 1}", paras.map { Block(0, it) }))
            }
            return out
        } finally {
            ex.close()
        }
    }
}
