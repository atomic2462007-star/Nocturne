package com.ereader.app.translate

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/** ترجمة إلى العربية عبر خدمة Google Translate المجانية (تحتاج إنترنت). */
object Translator {
    private const val ENDPOINT = "https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=ar&dt=t"
    private const val BATCH_CHARS = 3500
    private const val SPLIT_CHARS = 3000

    private fun once(text: String): String {
        val conn = URL(ENDPOINT).openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.doOutput = true
            conn.connectTimeout = 15000
            conn.readTimeout = 30000
            conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8")
            conn.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36")
            conn.outputStream.use { it.write(("q=" + URLEncoder.encode(text, "UTF-8")).toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            if (code != 200) throw IOException("HTTP $code")
            val body = conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            val segs = JSONArray(body).getJSONArray(0)
            val sb = StringBuilder()
            for (i in 0 until segs.length()) {
                val s = segs.optJSONArray(i) ?: continue
                if (s.isNull(0)) continue
                sb.append(s.optString(0, ""))
            }
            return sb.toString()
        } finally {
            conn.disconnect()
        }
    }

    /** ترجمة نص واحد مع إعادة المحاولة. */
    suspend fun translate(text: String): String = withContext(Dispatchers.IO) {
        if (text.isBlank()) return@withContext text
        var wait = 1000L
        for (attempt in 0 until 4) {
            try {
                return@withContext once(text)
            } catch (e: Exception) {
                if (e is kotlinx.coroutines.CancellationException) throw e
                if (attempt < 3) { delay(wait); wait *= 2 }
            }
        }
        throw IOException("تعذر الاتصال بخدمة الترجمة. تأكد من الإنترنت وحاول مرة أخرى")
    }

    private suspend fun translateLong(text: String): String {
        if (text.length <= SPLIT_CHARS) return translate(text)
        val parts = ArrayList<String>()
        var rest = text
        while (rest.length > SPLIT_CHARS) {
            var cut = rest.lastIndexOf(' ', SPLIT_CHARS)
            if (cut < SPLIT_CHARS / 2) cut = SPLIT_CHARS
            parts.add(rest.substring(0, cut))
            rest = rest.substring(cut).trimStart()
        }
        if (rest.isNotEmpty()) parts.add(rest)
        return parts.joinToString(" ") { p -> translate(p).also { delay(250) } }
    }

    /** ترجمة قائمة فقرات دفعات دفعات مع الحفاظ على عدد العناصر وترتيبها. */
    suspend fun translateList(items: List<String>): List<String> {
        val out = ArrayList<String>(items.size)
        var i = 0
        while (i < items.size) {
            var j = i
            var len = 0
            while (j < items.size && (j == i || len + items[j].length + 1 <= BATCH_CHARS)) { len += items[j].length + 1; j++ }
            val batch = items.subList(i, j)
            if (batch.size == 1) {
                out.add(translateLong(batch[0]))
            } else {
                val parts = translate(batch.joinToString("\n")).split("\n")
                if (parts.size == batch.size) out.addAll(parts.map { it.trim() })
                else batch.forEach { out.add(translateLong(it)); delay(200) }
            }
            i = j
            delay(250)
        }
        return out
    }
}
