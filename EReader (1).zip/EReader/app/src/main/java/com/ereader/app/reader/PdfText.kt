package com.ereader.app.reader

import android.content.Context
import android.graphics.RectF
import android.util.LruCache
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.io.MemoryUsageSetting
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import com.tom_roush.pdfbox.text.TextPosition
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.Closeable
import java.io.File
import kotlin.math.abs
import kotlin.math.max

/** نص صفحة PDF + مستطيل كل حرف (إحداثيات نسبية 0..1 من أعلى يسار الصفحة). */
class PdfPageText(val text: String, val rects: List<RectF>) {

    fun nearestChar(nx: Float, ny: Float, strict: Boolean): Int? {
        var best = -1
        var bd = Float.MAX_VALUE
        for (k in rects.indices) {
            val r = rects[k]
            if (r.isEmpty) continue
            val dx = max(max(r.left - nx, 0f), nx - r.right)
            val dy = max(max(r.top - ny, 0f), ny - r.bottom)
            val d = dx * dx + dy * dy
            if (d < bd) { bd = d; best = k }
        }
        if (best < 0) return null
        if (strict && bd > 0.0004f) return null
        return best
    }

    fun wordBounds(i: Int): Pair<Int, Int> {
        if (text.isEmpty()) return 0 to 0
        val idx = i.coerceIn(0, text.length - 1)
        var s = idx
        var e = idx + 1
        while (s > 0 && !text[s - 1].isWhitespace()) s--
        while (e < text.length && !text[e].isWhitespace()) e++
        return s to e
    }

    /** مستطيلات مدموجة لكل سطر لنطاق [start, end). */
    fun lineRects(start: Int, end: Int): List<RectF> {
        val out = ArrayList<RectF>()
        var cur: RectF? = null
        for (i in start.coerceAtLeast(0) until end.coerceAtMost(rects.size)) {
            val r = rects[i]
            if (r.isEmpty) {
                if (text[i] == '\n') { cur?.let { out.add(it) }; cur = null }
                continue
            }
            val c = cur
            if (c == null) cur = RectF(r)
            else if (abs((r.top + r.bottom) / 2f - (c.top + c.bottom) / 2f) < c.height() * 0.6f) c.union(r)
            else { out.add(c); cur = RectF(r) }
        }
        cur?.let { out.add(it) }
        return out
    }
}

/** تقسيم نص صفحة PDF إلى فقرات تقريبية (لدمج الأسطر المقطوعة). */
fun pdfParagraphs(text: String): List<String> {
    val out = ArrayList<String>()
    val cur = StringBuilder()
    for (raw in text.split('\n')) {
        val line = raw.trim()
        if (line.isEmpty()) continue
        if (cur.isNotEmpty()) {
            val last = cur[cur.length - 1]
            if (last in ".!?؟:؛\"”") { out.add(cur.toString()); cur.clear() } else cur.append(' ')
        }
        cur.append(line)
    }
    if (cur.isNotEmpty()) out.add(cur.toString())
    return out
}

class PdfTextExtractor(ctx: Context, private val file: File) : Closeable {
    private val mutex = Mutex()
    private var doc: PDDocument? = null
    @Volatile private var closed = false
    private val cache = LruCache<Int, PdfPageText>(40)

    init { PDFBoxResourceLoader.init(ctx.applicationContext) }

    private fun open(): PDDocument = doc ?: PDDocument.load(file, MemoryUsageSetting.setupTempFileOnly()).also { doc = it }

    suspend fun count(): Int = withContext(Dispatchers.IO) {
        mutex.withLock { if (closed) 0 else try { open().numberOfPages } catch (e: Exception) { 0 } }
    }

    suspend fun page(index: Int): PdfPageText? = withContext(Dispatchers.IO) {
        cache.get(index)?.let { return@withContext it }
        mutex.withLock {
            cache.get(index)?.let { return@withLock it }
            if (closed) return@withLock null
            try {
                extract(open(), index).also { cache.put(index, it) }
            } catch (e: Exception) {
                null
            }
        }
    }

    private fun extract(d: PDDocument, index: Int): PdfPageText {
        val page = d.getPage(index)
        val box = page.cropBox
        var w = box.width
        var h = box.height
        val rot = ((page.rotation % 360) + 360) % 360
        if (rot == 90 || rot == 270) { val t = w; w = h; h = t }
        val sb = StringBuilder()
        val rects = ArrayList<RectF>()
        val stripper = object : PDFTextStripper() {
            override fun writeString(text: String, textPositions: List<TextPosition>) {
                for (p in textPositions) {
                    val u = p.unicode ?: continue
                    val hh = if (p.heightDir > 0f) p.heightDir else p.fontSizeInPt
                    val l = p.xDirAdj / w
                    val r = (p.xDirAdj + p.widthDirAdj) / w
                    val t = (p.yDirAdj - hh) / h
                    val b = (p.yDirAdj + hh * 0.25f) / h
                    val rect = RectF(l, t, r, b)
                    for (ch in u) { sb.append(ch); rects.add(rect) }
                }
            }
            override fun writeWordSeparator() { sb.append(' '); rects.add(RectF()) }
            override fun writeLineSeparator() { sb.append('\n'); rects.add(RectF()) }
        }
        stripper.startPage = index + 1
        stripper.endPage = index + 1
        stripper.getText(d)
        return PdfPageText(sb.toString(), rects)
    }

    override fun close() {
        runBlocking {
            mutex.withLock {
                closed = true
                try { doc?.close() } catch (e: Exception) { }
                doc = null
            }
        }
        cache.evictAll()
    }
}
