package com.ereader.app.epub

import android.util.Xml
import org.xmlpull.v1.XmlPullParser
import java.io.File
import java.io.StringReader
import java.net.URLDecoder
import org.json.JSONObject
import java.util.zip.ZipFile

data class Block(val level: Int, val text: String)          // level 0 = فقرة، 1..6 = عنوان
data class Chapter(val title: String, val blocks: List<Block>)
class EpubInfo(val title: String?, val author: String?, val rtl: Boolean, val cover: ByteArray?)

object TextUtil {
    fun looksRtl(s: String): Boolean {
        var letters = 0
        var rtl = 0
        for (c in s) {
            if (c.isLetter()) {
                letters++
                if (c in '\u0590'..'\u08FF' || c in '\uFB1D'..'\uFDFF' || c in '\uFE70'..'\uFEFF') rtl++
            }
        }
        return letters > 0 && rtl * 10 > letters * 4
    }
}

object HtmlText {
    private val comment = Regex("(?s)<!--.*?-->")
    private val head = Regex("(?is)<head\\b.*?</head>")
    private val script = Regex("(?is)<(script|style)\\b.*?</\\1>")
    private val hOpen = Regex("(?i)<h([1-6])\\b[^>]*>")
    private val hClose = Regex("(?i)</h[1-6]\\s*>")
    private val br = Regex("(?i)<br\\s*/?>")
    private val blockTag = Regex("(?i)</?(p|div|li|tr|blockquote|section|article|ul|ol|table|body|header|footer|dd|dt|pre|figure|figcaption|aside)\\b[^>]*>")
    private val anyTag = Regex("<[^>]+>")
    private val ws = Regex("\\s+")
    private val entity = Regex("&(#[xX][0-9a-fA-F]+|#[0-9]+|[a-zA-Z]+);")
    private val named = mapOf(
        "amp" to "&", "lt" to "<", "gt" to ">", "quot" to "\"", "apos" to "'", "nbsp" to " ",
        "mdash" to "—", "ndash" to "–", "hellip" to "…", "laquo" to "«", "raquo" to "»",
        "lsquo" to "‘", "rsquo" to "’", "ldquo" to "“", "rdquo" to "”", "copy" to "©"
    )

    fun decode(s: String): String = entity.replace(s) { m ->
        val g = m.groupValues[1]
        val r: String? = runCatching {
            when {
                g.startsWith("#x") || g.startsWith("#X") -> String(Character.toChars(g.substring(2).toInt(16)))
                g.startsWith("#") -> String(Character.toChars(g.substring(1).toInt()))
                else -> named[g]
            }
        }.getOrNull()
        r ?: m.value
    }

    fun plain(s: String): String = decode(anyTag.replace(s, "")).replace('\u00A0', ' ').replace(ws, " ").trim()

    fun toBlocks(html: String): List<Block> {
        var s = html.removePrefix("\uFEFF")
        s = comment.replace(s, "")
        s = head.replace(s, "")
        s = script.replace(s, "")
        s = hOpen.replace(s) { "\n\u0001" + it.groupValues[1] + "\u0002" }
        s = hClose.replace(s, "\u0003\n")
        s = br.replace(s, "\n")
        s = blockTag.replace(s, "\n")
        s = anyTag.replace(s, "")
        val out = ArrayList<Block>()
        for (raw in s.split('\n')) {
            var line = raw
            var level = 0
            if (line.contains('\u0001')) {
                val after = line.substringAfter('\u0001')
                level = after.firstOrNull()?.digitToIntOrNull() ?: 2
                line = after.substringAfter('\u0002', after.drop(1))
            }
            line = line.replace("\u0003", "")
            val text = decode(line).replace('\u00A0', ' ').replace(ws, " ").trim()
            if (text.isNotEmpty()) out.add(Block(level, text))
        }
        return out
    }
}

object EpubParser {
    private class Item(val id: String, val href: String, val type: String, val props: String)
    private class Opf(
        val dir: String, val title: String?, val author: String?, val lang: String?, val coverId: String?,
        val manifest: Map<String, Item>, val spine: List<String>, val tocId: String?
    )

    private fun ZipFile.bytes(name: String): ByteArray? =
        getEntry(name)?.let { e -> getInputStream(e).use { it.readBytes() } }

    private fun ZipFile.text(name: String): String? =
        bytes(name)?.toString(Charsets.UTF_8)?.removePrefix("\uFEFF")

    private fun resolve(dir: String, href: String): String {
        val clean = href.substringBefore('#').substringBefore('?')
        val decoded = try { URLDecoder.decode(clean.replace("+", "%2B"), "UTF-8") } catch (e: Exception) { clean }
        val full = if (dir.isEmpty() || decoded.startsWith("/")) decoded.trimStart('/') else "$dir/$decoded"
        val stack = ArrayList<String>()
        for (part in full.split('/')) {
            when (part) {
                "", "." -> {}
                ".." -> if (stack.isNotEmpty()) stack.removeAt(stack.size - 1)
                else -> stack.add(part)
            }
        }
        return stack.joinToString("/")
    }

    private fun parseOpf(zip: ZipFile): Opf {
        val bad = IllegalArgumentException("ملف EPUB غير صالح")
        val container = zip.text("META-INF/container.xml") ?: throw bad
        val opfPath = Regex("""full-path\s*=\s*["']([^"']+)["']""").find(container)?.groupValues?.get(1) ?: throw bad
        val xml = zip.text(opfPath) ?: throw bad
        val dir = opfPath.substringBeforeLast('/', "")

        var title: String? = null
        var author: String? = null
        var lang: String? = null
        var coverId: String? = null
        var tocId: String? = null
        val manifest = LinkedHashMap<String, Item>()
        val spine = ArrayList<String>()

        val p = Xml.newPullParser()
        p.setInput(StringReader(xml))
        var ev = p.eventType
        while (ev != XmlPullParser.END_DOCUMENT) {
            if (ev == XmlPullParser.START_TAG) {
                when (p.name.substringAfter(':')) {
                    "title" -> if (title == null) title = p.nextText()
                    "creator" -> if (author == null) author = p.nextText()
                    "language" -> if (lang == null) lang = p.nextText()
                    "meta" -> if (p.getAttributeValue(null, "name") == "cover") coverId = p.getAttributeValue(null, "content")
                    "spine" -> tocId = p.getAttributeValue(null, "toc")
                    "item" -> {
                        val id = p.getAttributeValue(null, "id")
                        val href = p.getAttributeValue(null, "href")
                        if (id != null && href != null) {
                            manifest[id] = Item(id, href, p.getAttributeValue(null, "media-type") ?: "", p.getAttributeValue(null, "properties") ?: "")
                        }
                    }
                    "itemref" -> p.getAttributeValue(null, "idref")?.let { spine.add(it) }
                }
            }
            ev = p.next()
        }
        return Opf(dir, title, author, lang, coverId, manifest, spine, tocId)
    }

    /** يربط مسار ملف الفصل بعنوانه من فهرس المحتويات (NCX أو nav). */
    private fun parseToc(zip: ZipFile, opf: Opf): Map<String, String> {
        val map = LinkedHashMap<String, String>()
        try {
            val ncx = opf.manifest[opf.tocId ?: ""]
                ?: opf.manifest.values.firstOrNull { it.type == "application/x-dtbncx+xml" }
            if (ncx != null) {
                val ncxPath = resolve(opf.dir, ncx.href)
                val xml = zip.text(ncxPath)
                if (xml != null) {
                    val ncxDir = ncxPath.substringBeforeLast('/', "")
                    val p = Xml.newPullParser()
                    p.setInput(StringReader(xml))
                    var label: String? = null
                    var ev = p.eventType
                    while (ev != XmlPullParser.END_DOCUMENT) {
                        if (ev == XmlPullParser.START_TAG) {
                            when (p.name) {
                                "navPoint" -> label = null
                                "text" -> if (label == null) label = p.nextText().trim()
                                "content" -> {
                                    val src = p.getAttributeValue(null, "src")
                                    val l = label
                                    if (src != null && !l.isNullOrBlank()) map.putIfAbsent(resolve(ncxDir, src), l)
                                }
                            }
                        }
                        ev = p.next()
                    }
                }
            }
            if (map.isEmpty()) {
                val nav = opf.manifest.values.firstOrNull { it.props.contains("nav") }
                if (nav != null) {
                    val path = resolve(opf.dir, nav.href)
                    val html = zip.text(path)
                    val navDir = path.substringBeforeLast('/', "")
                    if (html != null) {
                        Regex("(?is)<a\\b[^>]*?href\\s*=\\s*[\"']([^\"']+)[\"'][^>]*>(.*?)</a>").findAll(html).forEach { m ->
                            val t = HtmlText.plain(m.groupValues[2])
                            if (t.isNotBlank()) map.putIfAbsent(resolve(navDir, m.groupValues[1]), t)
                        }
                    }
                }
            }
        } catch (e: Exception) { /* الفهرس اختياري */ }
        return map
    }

    /** بيانات سريعة عند الإضافة: العنوان، المؤلف، الاتجاه، الغلاف. */
    fun inspect(file: File): EpubInfo = ZipFile(file).use { zip ->
        val opf = parseOpf(zip)
        val coverItem = opf.manifest[opf.coverId ?: ""]?.takeIf { it.type.startsWith("image") }
            ?: opf.manifest.values.firstOrNull { it.props.contains("cover-image") }
            ?: opf.manifest.values.firstOrNull {
                it.type.startsWith("image") && (it.id.contains("cover", true) || it.href.contains("cover", true))
            }
        val cover = coverItem?.let { zip.bytes(resolve(opf.dir, it.href)) }

        val sb = StringBuilder()
        for (id in opf.spine) {
            if (sb.length > 2500) break
            val item = opf.manifest[id] ?: continue
            val html = zip.text(resolve(opf.dir, item.href)) ?: continue
            sb.append(HtmlText.toBlocks(html).joinToString(" ") { it.text }).append(' ')
        }
        val langRtl = opf.lang?.lowercase()?.let { l -> listOf("ar", "fa", "he", "ur").any { l.startsWith(it) } } ?: false
        EpubInfo(
            opf.title?.let { HtmlText.decode(it).trim() },
            opf.author?.let { HtmlText.decode(it).trim() },
            langRtl || TextUtil.looksRtl(sb.toString().take(4000)),
            cover
        )
    }

    /** يقرأ كل فصول الكتاب (بحسب ترتيب الـ spine). */
    private fun readJsonl(file: File): List<Chapter> {
        val out = ArrayList<Chapter>()
        file.useLines { lines ->
            for (l in lines) {
                if (l.isBlank()) continue
                try {
                    val o = JSONObject(l)
                    val arr = o.getJSONArray("b")
                    val blocks = ArrayList<Block>()
                    for (i in 0 until arr.length()) {
                        val p = arr.getJSONArray(i)
                        val t = p.getString(1)
                        if (t.isNotBlank()) blocks.add(Block(p.getInt(0), t))
                    }
                    if (blocks.isNotEmpty()) out.add(Chapter(o.optString("t", "فصل ${out.size + 1}"), blocks))
                } catch (e: Exception) { }
            }
        }
        return out
    }

    fun readChapters(file: File): List<Chapter> {
        if (file.name.endsWith(".jsonl")) return readJsonl(file)
        return readEpubChapters(file)
    }

    private fun readEpubChapters(file: File): List<Chapter> = ZipFile(file).use { zip ->
        val opf = parseOpf(zip)
        val toc = parseToc(zip, opf)
        val result = ArrayList<Chapter>()
        for (idref in opf.spine) {
            val item = opf.manifest[idref] ?: continue
            if (!item.type.contains("html") && !item.type.contains("xml")) continue
            val path = resolve(opf.dir, item.href)
            val html = zip.text(path) ?: continue
            val blocks = HtmlText.toBlocks(html)
            if (blocks.isEmpty()) continue
            val title = toc[path]
                ?: blocks.firstOrNull { it.level in 1..3 }?.text?.take(60)
                ?: "فصل ${result.size + 1}"
            result.add(Chapter(title, blocks))
        }
        result
    }
}
