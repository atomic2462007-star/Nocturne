package com.ereader.app.ui

import android.app.Activity
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ereader.app.AppViewModel
import com.ereader.app.data.BookEntity
import com.ereader.app.data.BookmarkEntity
import com.ereader.app.data.HighlightEntity
import com.ereader.app.translate.Translator
import kotlinx.coroutines.CancellationException
import kotlin.math.roundToInt

class ReaderUiState { var bars by mutableStateOf(false) }
data class TocItem(val title: String, val chapter: Int)

/** ألوان التحديد الأربعة (أصفر، أخضر، أزرق، وردي). */
object HlColors {
    val argb = listOf(0xFFFFD54F.toInt(), 0xFF81C784.toInt(), 0xFF64B5F6.toInt(), 0xFFF48FB1.toInt())
    fun color(i: Int) = argb[i.coerceIn(0, argb.lastIndex)]
}

fun setBrightness(activity: Activity, v: Float) {
    val lp = activity.window.attributes
    lp.screenBrightness = v   // -1 = سطوع النظام
    activity.window.attributes = lp
}

private enum class Sheet { None, Settings, Contents }
private val BarBg = Color(0xF2121212)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReaderOverlay(
    book: BookEntity, vm: AppViewModel, ui: ReaderUiState, isPdf: Boolean,
    pageIndex: Int, pageCount: Int, topLabel: String?,
    toc: List<TocItem>, bookmarks: List<BookmarkEntity>, highlights: List<HighlightEntity>, bookmarked: Boolean,
    onBack: () -> Unit, onToggleBookmark: () -> Unit,
    onJumpBookmark: (BookmarkEntity) -> Unit, onJumpHighlight: (HighlightEntity) -> Unit, onJumpToc: (TocItem) -> Unit,
    onGoToPage: (Int) -> Unit
) {
    var sheet by remember { mutableStateOf(Sheet.None) }
    var showGoto by remember { mutableStateOf(false) }
    val bookDir = if (book.isRtl) LayoutDirection.Rtl else LayoutDirection.Ltr
    val progress = if (pageCount > 0) (pageIndex + 1f) / pageCount else 0f
    val sub = if (book.isDark) Color(0xFF8E8E8E) else Color(0xFF6B6B6B)

    Box(Modifier.fillMaxSize()) {
        CompositionLocalProvider(LocalLayoutDirection provides bookDir) {
            LinearProgressIndicator(
                progress = { progress.coerceIn(0f, 1f) },
                modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(2.dp),
                color = sub, trackColor = Color.Transparent
            )
        }
        Text(
            "${pageIndex + 1}", color = sub, fontSize = 13.sp,
            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 16.dp)
        )
        if (!ui.bars && !topLabel.isNullOrBlank()) {
            Text(
                topLabel, color = sub, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                modifier = Modifier.align(Alignment.TopCenter).padding(top = 14.dp, start = 48.dp, end = 48.dp)
            )
        }

        AnimatedVisibility(
            ui.bars, Modifier.align(Alignment.TopCenter),
            enter = fadeIn() + slideInVertically { -it }, exit = fadeOut() + slideOutVertically { -it }
        ) {
            Row(
                Modifier.fillMaxWidth().background(BarBg).statusBarsPadding()
                    .pointerInput(Unit) { detectTapGestures { } }
                    .padding(horizontal = 4.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "رجوع", tint = Color.White) }
                Text(
                    book.title, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Medium,
                    maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f)
                )
                IconButton(onToggleBookmark) {
                    Icon(
                        if (bookmarked) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
                        "علامة مرجعية", tint = if (bookmarked) Color(0xFFFFD54F) else Color.White
                    )
                }
                IconButton({ sheet = Sheet.Contents }) { Icon(Icons.AutoMirrored.Filled.List, "الفهرس والعلامات والتحديدات", tint = Color.White) }
                IconButton({ sheet = Sheet.Settings }) { Icon(Icons.Default.TextFields, "إعدادات القراءة", tint = Color.White) }
            }
        }

        AnimatedVisibility(
            ui.bars, Modifier.align(Alignment.BottomCenter),
            enter = fadeIn() + slideInVertically { it }, exit = fadeOut() + slideOutVertically { it }
        ) {
            Column(
                Modifier.fillMaxWidth().background(BarBg).navigationBarsPadding()
                    .pointerInput(Unit) { detectTapGestures { } }
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("${(progress * 100).roundToInt()}%", color = Color(0xFFBDBDBD), fontSize = 13.sp)
                    Spacer(Modifier.weight(1f))
                    TextButton({ showGoto = true }) { Text("صفحة ${pageIndex + 1} من $pageCount  ·  انتقال", color = Color.White, fontSize = 13.sp) }
                }
                var drag by remember { mutableStateOf<Float?>(null) }
                CompositionLocalProvider(LocalLayoutDirection provides bookDir) {
                    Slider(
                        value = drag ?: pageIndex.toFloat(),
                        onValueChange = { drag = it },
                        onValueChangeFinished = { drag?.let { onGoToPage(it.roundToInt()) }; drag = null },
                        valueRange = 0f..(pageCount - 1).coerceAtLeast(1).toFloat(),
                        colors = SliderDefaults.colors(
                            thumbColor = Color.White, activeTrackColor = Color(0xFFCCCCCC), inactiveTrackColor = Color(0xFF3A3A3A)
                        )
                    )
                }
                Spacer(Modifier.height(10.dp))
            }
        }
    }

    if (sheet != Sheet.None) {
        ModalBottomSheet(onDismissRequest = { sheet = Sheet.None }, containerColor = Color(0xFF151515)) {
            if (sheet == Sheet.Settings) {
                SettingsContent(book, vm, isPdf)
            } else {
                ContentsContent(
                    toc, bookmarks, highlights, isPdf,
                    onToc = { sheet = Sheet.None; onJumpToc(it) },
                    onBookmark = { sheet = Sheet.None; onJumpBookmark(it) },
                    onHighlight = { sheet = Sheet.None; onJumpHighlight(it) },
                    onDeleteBookmark = { vm.deleteBookmark(it.id) },
                    onDeleteHighlight = { vm.deleteHighlight(it.id) }
                )
            }
            Spacer(Modifier.navigationBarsPadding().height(12.dp))
        }
    }

    if (showGoto) {
        var text by remember { mutableStateOf("${pageIndex + 1}") }
        val submit = {
            text.toIntOrNull()?.let { if (it in 1..pageCount) { onGoToPage(it - 1); showGoto = false } }
            Unit
        }
        AlertDialog(
            onDismissRequest = { showGoto = false },
            title = { Text("الانتقال إلى صفحة") },
            text = {
                OutlinedTextField(
                    value = text, onValueChange = { text = it.filter(Char::isDigit).take(6) },
                    singleLine = true, label = { Text("من 1 إلى $pageCount") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                )
            },
            confirmButton = { TextButton({ submit() }) { Text("انتقال") } },
            dismissButton = { TextButton({ showGoto = false }) { Text("إلغاء") } }
        )
    }
}

/** شريط التحديد: ألوان + ترجمة (+ حذف عند تعديل تحديد موجود). */
@Composable
fun SelectionBar(
    modifier: Modifier, existing: Boolean,
    onColor: (Int) -> Unit, onTranslate: () -> Unit, onDelete: () -> Unit, onClose: () -> Unit
) {
    Row(
        modifier.background(Color(0xF0222222), RoundedCornerShape(28.dp))
            .pointerInput(Unit) { detectTapGestures { } }
            .padding(horizontal = 10.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        HlColors.argb.forEachIndexed { i, c ->
            Box(Modifier.size(34.dp).clip(CircleShape).background(Color(c)).clickable { onColor(i) })
        }
        Box(Modifier.width(1.dp).height(26.dp).background(Color(0xFF555555)))
        IconButton(onTranslate, Modifier.size(38.dp)) { Icon(Icons.Default.Translate, "ترجمة", tint = Color.White) }
        if (existing) IconButton(onDelete, Modifier.size(38.dp)) { Icon(Icons.Default.Delete, "حذف التحديد", tint = Color(0xFFFF8A80)) }
        IconButton(onClose, Modifier.size(38.dp)) { Icon(Icons.Default.Close, "إغلاق", tint = Color(0xFFBDBDBD)) }
    }
}

@Composable
fun TranslateDialog(text: String, onClose: () -> Unit) {
    val result by produceState<String?>(null, text) {
        value = try {
            Translator.translate(text.take(4500))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            "تعذرت الترجمة: ${e.message ?: ""}"
        }
    }
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("الترجمة إلى العربية") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Text(text, fontSize = 12.sp, color = Color(0xFF8A8A8A), maxLines = 6, overflow = TextOverflow.Ellipsis)
                Spacer(Modifier.height(10.dp))
                HorizontalDivider()
                Spacer(Modifier.height(10.dp))
                val r = result
                if (r == null) CircularProgressIndicator(Modifier.size(28.dp), strokeWidth = 2.dp)
                else Text(r, fontSize = 17.sp, lineHeight = 29.sp)
            }
        },
        confirmButton = { TextButton(onClose) { Text("إغلاق") } }
    )
}

@Composable
private fun SectionTitle(t: String) = Text(t, fontSize = 14.sp, color = Color(0xFF9A9A9A), fontWeight = FontWeight.Medium)

@Composable
private fun SettingsContent(book: BookEntity, vm: AppViewModel, isPdf: Boolean) {
    val activity = LocalContext.current as Activity
    Column(
        Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 20.dp).padding(bottom = 12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        SectionTitle("المظهر")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = book.isDark, onClick = { vm.saveDark(book.id, true) }, label = { Text("داكن (Dark)") })
            FilterChip(selected = !book.isDark, onClick = { vm.saveDark(book.id, false) }, label = { Text("فاتح (Light)") })
        }

        if (!isPdf) {
            SectionTitle("حجم الخط")
            var size by remember(book.fontSizeSp) { mutableFloatStateOf(book.fontSizeSp) }
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton({ vm.saveText(book.id, (size - 1f).coerceAtLeast(14f), book.fontFamily, book.lineSpacing) }) { Icon(Icons.Default.Remove, "تصغير") }
                Slider(
                    value = size, onValueChange = { size = it },
                    onValueChangeFinished = { vm.saveText(book.id, size.roundToInt().toFloat(), book.fontFamily, book.lineSpacing) },
                    valueRange = 14f..40f, modifier = Modifier.weight(1f)
                )
                IconButton({ vm.saveText(book.id, (size + 1f).coerceAtMost(40f), book.fontFamily, book.lineSpacing) }) { Icon(Icons.Default.Add, "تكبير") }
                Text("${size.roundToInt()}", fontSize = 14.sp, modifier = Modifier.width(28.dp))
            }

            SectionTitle("نوع الخط")
            val fonts = listOf("serif" to "نسخ (Serif)", "sans" to "Sans", "sans_medium" to "Sans متوسط", "mono" to "Mono")
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                fonts.forEach { (k, l) ->
                    FilterChip(
                        selected = book.fontFamily == k,
                        onClick = { vm.saveText(book.id, book.fontSizeSp, k, book.lineSpacing) },
                        label = { Text(l) }
                    )
                }
            }

            SectionTitle("تباعد الأسطر")
            var ls by remember(book.lineSpacing) { mutableFloatStateOf(book.lineSpacing) }
            Slider(
                value = ls, onValueChange = { ls = it },
                onValueChangeFinished = { vm.saveText(book.id, book.fontSizeSp, book.fontFamily, ls) },
                valueRange = 1.1f..2.2f
            )
        } else {
            Text("تكبير وتصغير: بإصبعين، أو بالنقر مرتين على الصفحة.", fontSize = 12.sp, color = Color(0xFF8A8A8A))
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("تقليب الصفحات من اليمين إلى اليسار", Modifier.weight(1f), fontSize = 14.sp)
            Switch(book.isRtl, { vm.saveRtl(book.id, it) })
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("سطوع الشاشة", Modifier.weight(1f), fontSize = 14.sp)
            Text("تلقائي", fontSize = 13.sp, color = Color(0xFF9A9A9A))
            Spacer(Modifier.width(8.dp))
            Switch(
                checked = book.brightness < 0,
                onCheckedChange = { auto -> vm.saveBrightness(book.id, if (auto) -1f else 0.5f) }
            )
        }
        if (book.brightness >= 0) {
            var br by remember(book.brightness) { mutableFloatStateOf(book.brightness) }
            Slider(
                value = br,
                onValueChange = { br = it; setBrightness(activity, it) },
                onValueChangeFinished = { vm.saveBrightness(book.id, br) },
                valueRange = 0.02f..1f
            )
        }

        if (!book.isRtl) {
            var confirm by remember { mutableStateOf(false) }
            HorizontalDivider()
            SectionTitle("الترجمة")
            OutlinedButton({ confirm = true }, Modifier.fillMaxWidth()) { Text("ترجمة الكتاب كله إلى العربية") }
            Text("تحدد جزءًا من النص (ضغطة مطوّلة ثم سحب) واختر أيقونة الترجمة لترجمته فقط.", fontSize = 12.sp, color = Color(0xFF8A8A8A))
            if (confirm) {
                AlertDialog(
                    onDismissRequest = { confirm = false },
                    title = { Text("ترجمة الكتاب كله؟") },
                    text = { Text("ستُنشأ نسخة عربية في مكتبتك. تحتاج إنترنت وقد تستغرق دقائق إلى ساعة حسب حجم الكتاب. ابقِ التطبيق مفتوحًا، وإن توقفت يكمل من حيث وصل.") },
                    confirmButton = {
                        TextButton({
                            confirm = false
                            vm.translateBook(book)
                            Toast.makeText(activity, "بدأت الترجمة، تابعها من المكتبة", Toast.LENGTH_LONG).show()
                        }) { Text("ابدأ") }
                    },
                    dismissButton = { TextButton({ confirm = false }) { Text("إلغاء") } }
                )
            }
        }
    }
}

@Composable
private fun ContentsContent(
    toc: List<TocItem>, bookmarks: List<BookmarkEntity>, highlights: List<HighlightEntity>, isPdf: Boolean,
    onToc: (TocItem) -> Unit, onBookmark: (BookmarkEntity) -> Unit, onHighlight: (HighlightEntity) -> Unit,
    onDeleteBookmark: (BookmarkEntity) -> Unit, onDeleteHighlight: (HighlightEntity) -> Unit
) {
    val tabs = remember(toc.isNotEmpty()) { buildList { if (toc.isNotEmpty()) add("toc"); add("bm"); add("hl") } }
    var tab by remember { mutableIntStateOf(0) }
    val idx = tab.coerceIn(0, tabs.lastIndex)
    Column {
        TabRow(selectedTabIndex = idx, containerColor = Color.Transparent) {
            tabs.forEachIndexed { i, k ->
                Tab(idx == i, { tab = i }) {
                    Text(
                        when (k) { "toc" -> "الفهرس"; "bm" -> "العلامات (${bookmarks.size})"; else -> "التحديدات (${highlights.size})" },
                        Modifier.padding(14.dp), fontSize = 13.sp
                    )
                }
            }
        }
        LazyColumn(Modifier.fillMaxWidth().heightIn(max = 460.dp)) {
            when (tabs[idx]) {
                "toc" -> items(toc) { t ->
                    Text(
                        t.title, maxLines = 2, overflow = TextOverflow.Ellipsis, fontSize = 15.sp,
                        modifier = Modifier.fillMaxWidth().clickable { onToc(t) }.padding(horizontal = 20.dp, vertical = 14.dp)
                    )
                }
                "bm" -> if (bookmarks.isEmpty()) {
                    item {
                        Text(
                            "لا توجد علامات بعد. اضغط على أيقونة العلامة في الشريط العلوي لإضافة علامة للصفحة الحالية.",
                            color = Color(0xFF8A8A8A), fontSize = 13.sp, modifier = Modifier.padding(20.dp)
                        )
                    }
                } else {
                    items(bookmarks) { b ->
                        Row(
                            Modifier.fillMaxWidth().clickable { onBookmark(b) }.padding(start = 20.dp, end = 8.dp, top = 6.dp, bottom = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Bookmark, null, tint = Color(0xFFFFD54F), modifier = Modifier.size(20.dp))
                            Spacer(Modifier.width(12.dp))
                            Text(b.label, Modifier.weight(1f), maxLines = 2, overflow = TextOverflow.Ellipsis, fontSize = 14.sp)
                            IconButton({ onDeleteBookmark(b) }) { Icon(Icons.Default.Delete, "حذف", tint = Color(0xFF9A9A9A)) }
                        }
                    }
                }
                else -> if (highlights.isEmpty()) {
                    item {
                        Text(
                            "لا توجد تحديدات بعد. اضغط مطوّلًا على كلمة ثم اسحب لتحديد النص، واختر لونًا.",
                            color = Color(0xFF8A8A8A), fontSize = 13.sp, modifier = Modifier.padding(20.dp)
                        )
                    }
                } else {
                    items(highlights) { h ->
                        Row(
                            Modifier.fillMaxWidth().clickable { onHighlight(h) }.padding(start = 20.dp, end = 8.dp, top = 6.dp, bottom = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(Modifier.size(14.dp).clip(CircleShape).background(Color(HlColors.color(h.color))))
                            Spacer(Modifier.width(12.dp))
                            Text(
                                (if (isPdf) "ص ${h.chapter + 1} · " else "") + h.snippet,
                                Modifier.weight(1f), maxLines = 3, overflow = TextOverflow.Ellipsis, fontSize = 14.sp
                            )
                            IconButton({ onDeleteHighlight(h) }) { Icon(Icons.Default.Delete, "حذف", tint = Color(0xFF9A9A9A)) }
                        }
                    }
                }
            }
        }
    }
}
